#!/usr/bin/env python3
"""场景分析工作簿校验器(跨平台,openpyxl 实现)。

复刻自 verify-workbook.mjs,去掉 OpenAI 专属的 @oai/artifact-tool 依赖,
改用 openpyxl,可在 Mac / Windows / Linux 通用运行。

用法:
    python verify_workbook.py <workbook.xlsx>
    # Windows: py -3 verify_workbook.py <workbook.xlsx>

校验四项(任一不通过 → 退出码 1):
    1. sheetOrderValid       —— 五个 Sheet 顺序严格正确
    2. formulaErrors         —— 全表无公式错误(#REF! / #DIV/0! / #VALUE! / #NAME? / #N/A)
    3. rawImages==galleryImages —— "抓取原始数据"与"所有图片合集"嵌入图片数一致
    4. problemTotalShareBlank —— "产品解决什么问题"行的"总占比"(第7列)单元格为空
"""
import sys
import json
import re

try:
    from openpyxl import load_workbook
except ImportError:
    sys.stderr.write(
        "缺少依赖 openpyxl。请先安装:\n"
        "    pip install openpyxl\n"
        "    # Windows 若 pip 不可用: py -3 -m pip install openpyxl\n"
    )
    sys.exit(2)

ERR_PATTERN = re.compile(r"#REF!|#DIV/0!|#VALUE!|#NAME\?|#N/A")
EXPECTED_SHEETS = [
    "场景分析占比",
    "场景分析总结报告",
    "场景分析总结结论",
    "抓取原始数据",
    "所有图片合集",
]


def count_images(ws):
    """统计一个 worksheet 的嵌入图片数(openpyxl 私有属性,做防御性兜底)。"""
    imgs = getattr(ws, "_images", None)
    if imgs is None:
        return 0
    try:
        return len(imgs)
    except TypeError:
        return 0


def has_formula_errors(wb):
    """扫描全表所有单元格,匹配公式错误字面量。

    data_only=False 时读到的是公式文本 / 存储值,能覆盖 #REF! #NAME? 等
    由公式引用错误写入的字面量。"""
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None:
                    continue
                if ERR_PATTERN.search(str(v)):
                    return True
    return False


def problem_total_share_blank(ws_ratio):
    """"产品解决什么问题"所在行的第7列(总占比)必须为空。

    匹配逻辑对齐 mjs:第1列含"产品解决什么问题" 或 第2列 == "解决什么问题"。"""
    max_row = ws_ratio.max_row or 0
    for r in range(1, max_row + 1):
        col1 = str(ws_ratio.cell(row=r, column=1).value or "")
        col2 = str(ws_ratio.cell(row=r, column=2).value or "")
        if "产品解决什么问题" in col1 or col2 == "解决什么问题":
            col7 = ws_ratio.cell(row=r, column=7).value
            if col7 not in (None, ""):
                return False
    return True


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("用法: python verify_workbook.py <workbook.xlsx>\n")
        sys.exit(2)

    path = sys.argv[1]
    try:
        wb = load_workbook(path, data_only=False)
    except Exception as e:  # noqa: BLE001 - 给用户清晰错误
        sys.stderr.write(f"无法打开工作簿: {path}\n{e}\n")
        sys.exit(2)

    sheets = list(wb.sheetnames)
    sheet_order_valid = sheets == EXPECTED_SHEETS

    formula_errors = has_formula_errors(wb)

    # 缺 Sheet 时给出明确降级,不因 KeyError 崩溃
    missing = [s for s in ("抓取原始数据", "所有图片合集", "场景分析占比") if s not in sheets]
    if missing:
        result = {
            "sheetOrderValid": sheet_order_valid,
            "formulaErrors": formula_errors,
            "missingSheets": missing,
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        sys.exit(1)

    raw_images = count_images(wb["抓取原始数据"])
    gallery_images = count_images(wb["所有图片合集"])
    problem_blank = problem_total_share_blank(wb["场景分析占比"])

    result = {
        "sheetOrderValid": sheet_order_valid,
        "formulaErrors": formula_errors,
        "rawImages": raw_images,
        "galleryImages": gallery_images,
        "problemTotalShareBlank": problem_blank,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if (
        not sheet_order_valid
        or formula_errors
        or raw_images != gallery_images
        or not problem_blank
    ):
        sys.exit(1)


if __name__ == "__main__":
    main()
